const fetch = require('node-fetch');

exports.handler = async function(event) {
  const period = event.queryStringParameters.period || 'day';

  try {
    const res = await fetch(`https://www.reddit.com/r/internetisbeautiful/top.json?limit=10&t=${period}`);
    const data = await res.json();
    return {
      statusCode: 200,
      headers: { "Access-Control-Allow-Origin": "*" },
      body: JSON.stringify(data)
    };
  } catch (error) {
    return {
      statusCode: 500,
      body: JSON.stringify({ error: "Failed to fetch Reddit data" })
    };
  }
};
